$(function(){
	$('.purchaselist-info').dblclick(function(){
		console.log($(this).data('info'));

		$(".add-con-area").show();
        $(".add-alert-area").show();


	});




});