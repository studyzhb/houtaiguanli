<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>js代码网提示你，你访问的页面找不回来了！_js代码</title>
<style type="text/css">
a,img{border:0;}
.pages_404 { margin:220px auto auto auto;width:397px;height:377px;}
</style>
</head>
<body>
<div class="pages_404">
  404
</div>
</body>
</html>