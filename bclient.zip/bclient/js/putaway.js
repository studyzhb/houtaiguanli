layui.use('element', function(){
  var element = layui.element();
  
});


$(function(){

	config.ajax('get',config.ajaxAddress.publicAddress+config.ajaxAddress.showShopGoods,function(data){
		console.log(data);
	},{status:1});





})