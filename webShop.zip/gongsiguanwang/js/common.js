// JavaScript Document
$(function(){
	"use strict";

/*首页fullpage的js文件start*/

$('#full').fullpage({
	
    anchors:['firstPage', 'secondPage', 'thirdPage','forthPage','fivthPage','sixthPage','sevenPage'],
    menu:'#menu',
	navigation:true,
	
	controlArrowColor:'#666',
	css3:true,
	scrollingSpeed:200,
	slidesNavigation:true,
	slidesNavPosition:'bottom',
	controlArrows: false ,
	resize:true,
	afterLoad: function(anchorLink, index){
			if(index === 3){
				$('.case').animate({'top': '30px'}, 1000, 'swing');
			}
			if(index === 4){
				$('.qua1').animate({'left': '0'}, 1000, 'swing');
				$('.qua2').animate({'top': '0'}, 1500, 'swing');
				$('.qua3').animate({'right': '0'}, 1000, 'swing');
			}if(index===5){
				$('.marking li div').animate({'top': '10px'}, 1000, 'swing');
			}if(index===7){
				$('.message-contact').fadeIn(1500);
           }
			   
		},
	onLeave:function(index,ni,d){
		 if(index===1 && d==='down'){
			$('.headmove').css({'background':'rgba(0,0,0,0.6)'});
			$('.headmove #menu li a').css({'font-size':'14px'});	
		}else if(index===2 && d==='up'){
			$('.headmove').css({'background':'rgba(0,0,0,0.1)'});
			$('.headmove #menu li a').css({'font-size':'20px'});
		}if(index===3){
			$('.case').animate({'top': '100%'}, 1000, 'swing');
			
		}if(index===4){
			$('.qua1').animate({'left': '-100%'}, 1000, 'swing');
			$('.qua2').animate({'top': '1000px'}, 1500, 'swing');
			$('.qua3').animate({'right': '-100%'}, 1000, 'swing');
		}if(index===5){
				$('.marking li div').animate({'top': '100%'}, 1000, 'swing');	
		}if(index===7){
		$('.message-contact').fadeOut(1500);
		}
		
	},afterSlideLoad: function(anchorLink, index, slideAnchor, slideIndex){
		  if(index===1){
			  if(slideIndex===0){
				   $('.fp-slide1').animate({'top': '-30px'}, 1000, 'swing');
				  }
			  if(slideIndex===1){
				 $('.fp-slide2').animate({'right': '0'}, 1000, 'swing');
				  }
			  if(slideIndex===2){
			  $('.fp-slide3').animate({'left': '0'}, 1000, 'swing');
			  }
			  if(slideIndex===3){
			  $('.fp-slide4').animate({'left': '0'}, 1000, 'swing');
			  }
		  }
		},
        /*onSlideLeave: function(anchorLink, index, slideIndex, direction, nextSlideIndex){},
	
	*/
	
});
/*首页fullpage的js文件end*/


setInterval(function(){
        $.fn.fullpage.moveSlideRight();
    }, 3500);


   
	


});
	
	

		
		
