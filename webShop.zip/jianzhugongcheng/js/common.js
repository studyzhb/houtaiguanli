// JavaScript Document
$(function(){
	"use strict";
/*index首页start*/
//导航js文件
    $('.nav li').click(function(){
		$(this).addClass('nav-active').siblings().removeClass('nav-active');
	});
//内容导航js文件
	$(".side-nav-left li").hover(function(){
		$(".side-nav-right").fadeIn();
		var index=$(this).index(".side-nav-left li");
		$($(".side-nav-right .content")[index]).fadeIn().siblings().fadeOut();
		},function(){
			
		});
	$(".side-nav").mouseleave(function(){
			$(".side-nav-right").fadeOut();
			$(".side-nav-right .content").fadeOut();
	});
//左侧悬浮导航
 $(window).scroll(function () {
        var scrollTop = $(document).scrollTop();
        var documentHeight = $(document).height();
        var windowHeight = $(window).height();
        var contentItems = $("#content").find(".goods");
        var currentItem = "";
if(scrollTop>650){$('#menu').css('display','block');}else{$('#menu').css('display','none');}
        if (scrollTop+windowHeight===documentHeight) {
            currentItem= "#" + contentItems.last().attr("id");
        }else{
            contentItems.each(function () {
                var contentItem = $(this);
                var offsetTop = contentItem.offset().top;
                if (scrollTop > offsetTop - 460) {//此处的200视具体情况自行设定，因为如果不减去一个数值，在刚好滚动到一个div的边缘时，菜单的选中状态会出错，比如，页面刚好滚动到第一个div的底部的时候，页面已经显示出第二个div，而菜单中还是第一个选项处于选中状态
                    currentItem = "#" + contentItem.attr("id");
                }
            });
        }
        if (currentItem !== $("#menu").find(".current").attr("href")) {
            $("#menu").find(".current").removeClass("current");
            $("#menu").find("[href=" + currentItem + "]").addClass("current");
        }
    });
//右侧悬浮导航
$('.rightbar li.top').click(function(){
    $("html, body").animate({ scrollTop: 0 }, 500);	
	});
/*index首页end*/	
	
	


	
/*goods-type商品start*/
//商品类型展开和收起
$('.goods-select li a.open').click(function(){
	$('.goods-select>li.brand ').css({'height':'150px','overflow':'auto'});
	$('.goods-select>li.brand .title').css({'height':'150px'});
	$('.goods-select li a.open').css('display','none');
	$('.goods-select li a.close').css('display','block');
	});
	
$('.goods-select li a.close').click(function(){
	$('.goods-select>li.brand ').css({'height':'88px','overflow':'hidden'});
	$('.goods-select>li.brand .title').css({'height':'88px'});
	$('.goods-select li a.close').css('display','none');
	$('.goods-select li a.open').css('display','block');
	});
//商品排序js文件
$('.order-top-left ul li').click(function(){
	$(this).find('a').css({'color':'#fff'}).siblings().css({'color':'#666'});
	$(this).css({'background':'#f04356'}).siblings().css({'background':'#fff'});
	$(this).find('i').css('background-position','-51px -61px').siblings().css('background-position','-31px -61px');
	});
$('.goods-con ul li:nth-child(4n)').css('margin-right','0');
/*goods-type商品end*/	



/*登录start*/
$('.login-right form input').focus(function(){
	$(this).parent().css({'border-color':'#f04356','color':'#f04356'}).siblings().css({'border-color':'#d9d9d9','color':'#666'});
	
	});
/*$('.register form input').focus(function(){
	if( $(this).is('#user') ){
		
	$(this).parent().css({'border-color':'#f04356','color':'#f04356'});
	
	});*/
$('.register form input').blur(function(){
     var $parent = $(this).parent().parent();
	 //用户名验证
	 if( $(this).is('#user') ){
		if( this.value==="" || this.value.length < 6 ){
			var errorMsg = '请输入至少6位的用户名';
			$parent.append('<span class="formtips onError">'+errorMsg+'</span>');
		}else{
			var okMsg = '输入正确.';
			$parent.append('<span class="formtips onSuccess">'+okMsg+'</span>');
		}
    }
	//验证码验证
	if( $(this).is('#identy') ){
		if( this.value==="" ){
			var errorMsg = '请输入验证码';
			$parent.append('<span class="formtips onError">'+errorMsg+'</span>');
		}else if(this.value!==$('.yanzheng').html()){
			var errorMsg = '验证码错误';
			$parent.append('<span class="formtips onError">'+errorMsg+'</span>');
		}else{
			var okMsg = '输入正确';
			$parent.append('<span class="formtips onSuccess">'+okMsg+'</span>');
		}
    }
	//短信验证
	if( $(this).is('#check') ){
		if( this.value==="" ){
			var errorMsg = '请输入短信验证码';
			$parent.append('<span class="formtips onError">'+errorMsg+'</span>');
		}else if(this.value!==$('.yanzheng').html()){
			var errorMsg = '验证码错误';
			$parent.append('<span class="formtips onError">'+errorMsg+'</span>');
		}else{
			var okMsg = '输入正确';
			$parent.append('<span class="formtips onSuccess">'+okMsg+'</span>');
		}
    }
	//密码验证
	if( $(this).is('#pwd') ){
		if( this.value===""  ){
			var errorMsg = '请输入密码';
			$parent.append('<span class="formtips onError">'+errorMsg+'</span>');
		}else if(this.value.length < 6){
			var errorMsg = '密码至少为6位';
			$parent.append('<span class="formtips onError">'+errorMsg+'</span>');
		}else{
			var okMsg = '输入正确';
			$parent.append('<span class="formtips onSuccess">'+okMsg+'</span>');
		}
    }
	
	//密码确认验证
	if( $(this).is('#npwd') ){
		if( this.value==="" ){
			var errorMsg = '请确认密码';
			$parent.append('<span class="formtips onError">'+errorMsg+'</span>');
		}else if(this.value!==$('#pwd').value){
			var errorMsg = '两次密码输入不一致';
			$parent.append('<span class="formtips onError">'+errorMsg+'</span>');
		}else{
			var okMsg = '输入正确';
			$parent.append('<span class="formtips onSuccess">'+okMsg+'</span>');
		}
    }	
	
});
/*登录end*/



/*商品详情start*/
$('.choice ul li:last-child').css('border-color','#f04356');
$('.choice ul li').click(function(){
	$(this).css('border-color','#f04356').siblings().css('border-color','#fff');
	});
/*商品详情end*/
});