// layer弹窗  －－－ 模拟layer
var layerObj = function(){
	this.setLayerPos = function setLayerPos(){
		$('.layerBox').css({'margin-left': -$('.layerBox').innerWidth()/2}).addClass('layer-ani');
	},
	this.addEle = function addEle(){
		$('body').append(
			'<div class="layerBox">'+
				'<div class="layerContent"></div>'+
			'</div>'
		);
	},
	this.msg = function msg(text,time){
		if($('.layerBox').length > 0){
			$('.layerBox').remove();
			return;
		}else{
			this.addEle();
		}

		$('.layerContent').html(text).css({'opacity':1});
		this.setLayerPos();
		var timer = setTimeout(function(){
			$('.layerBox').remove();
			clearTimeout(timer);
		},time)	
	}
}
var layer = new layerObj();

//  ------------------- 通用 方法  -------------------------
function bodyScroll(e){ e.preventDefault() }
var browser = {
	versions: function () {
        var u = navigator.userAgent, app = navigator.appVersion;
        return {         //移动终端浏览器版本信息
            trident: u.indexOf('Trident') > -1, //IE内核
            presto: u.indexOf('Presto') > -1, //opera内核
            webKit: u.indexOf('AppleWebKit') > -1, //苹果、谷歌内核
            gecko: u.indexOf('Gecko') > -1 && u.indexOf('KHTML') == -1, //火狐内核
            mobile: !!u.match(/AppleWebKit.*Mobile.*/), //是否为移动终端
            ios: !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/), //ios终端
            android: u.indexOf('Android') > -1 || u.indexOf('Linux') > -1, //android终端或uc浏览器
            iPhone: u.indexOf('iPhone') > -1, //是否为iPhone或者QQHD浏览器
            iPad: u.indexOf('iPad') > -1, //是否iPad
            webApp: u.indexOf('Safari') == -1 //是否web应该程序，没有头部与底部
        };
    }(),
    language: (navigator.browserLanguage || navigator.language).toLowerCase()
}


if (browser.versions.mobile) {
        $('#btn-normal-download').bind('click',function(){
                var ua = navigator.userAgent.toLowerCase();
                if (ua.match(/MicroMessenger/i) == "micromessenger") {
                        console.log('微信');
                        if(browser.versions.ios) {
                                console.log('IOS');
                                window.location.href = 'http://a.app.qq.com/o/simple.jsp?pkgname=com.xiaodao.client.kanduoduo';
                        }else{
                                console.log('安卓');
                                $('.shade').show();
                                document.addEventListener('touchmove', bodyScroll, false);
                        }
                }else{
                        console.log('浏览器');
                        if(browser.versions.ios) {
                                console.log('IOS');
                                window.location.href = 'https://itunes.apple.com/cn/app/kan-duo-duo/id1073326937';
                        }else{
                                console.log('安卓');
                                window.location.href = 'http://kanduoduo-file.oss-cn-hangzhou.aliyuncs.com/QM-kandd-1.0.8-201606231532-360-201606241022.apk ';
                        }
                }
        })

} else {
       console.log('请在移动端打开');
       alert('请在移动端打开');
}

$('.shade').bind('click',function(){
    $(this).hide();
    document.removeEventListener('touchmove', bodyScroll, false);
})
//---------  像素比例计算
function val(argument) {
	var htmlFontSize = 1 / parseFloat($('html').css('font-size'));
	var curWidth = document.documentElement.clientWidth;
	// 效果图比例
	var curPrecent = (1080 / 375);
	console.log('当前像素: ' + argument / curPrecent + 'px' + ' , ' + (argument / curPrecent).toFixed(0));
	console.log('转换后为: ' + ((argument / curPrecent) * 0.0266666666666667).toFixed(3) + 'rem');
};

//---------  判断是否是手机号
function isMobile(value) {
	if(value == undefined || value == null) {
		return false;
	}
	var patrn = /((1[34578][0-9]{1}))\d{8}/;
	return patrn.test(value);
}
//--------  手机号验证
var isGet = false;
$("#mobile").keyup(function() {
	var mobileStr = $(this).val();
	if(isMobile(mobileStr)) {
		$("#btn_getCode").addClass("getCode1").removeAttr("disabled");
		isGet = true;
	} else if(mobileStr.length == "11") {
		layer.msg("手机号不正确");
		$("#btn_getCode").attr("disabled", "disabled");
	}
});

//------- 验证码倒计时
var temptime = 5; //验证码重新发送倒计时
var timer;

function countdown(obj) {
	if(temptime == 0) {
		temptime = 10;
		clearTimeout(timer);
		$("#btn_getCode").val('重新发送').removeAttr("disabled");
	} else {
		$("#btn_getCode").val('验证码(' + temptime + ')');
		temptime = temptime - 1;
		if(temptime >= 0) {
			clearTimeout(timer);
			timer = setTimeout(function() {
				countdown(obj);
			}, 1000);
		}
	}
}
//-------  验证码重新获取倒计时
function djs() {
	$("#btn_getCode").attr("disabled", "disabled");
	countdown();
}

//-------- 提交信息
$("#btn_sumbit").bind('click', function() {
	var myobj = $("#mobile")[0];
	var mobile = $("#mobile").val();
	var code = $("#code").val();
	if(mobile == "") {
		layer.msg("手机号不可为空");
		$('#mobile').focus();
		return false;
	}
	if(code == "") {
		layer.msg("验证码不可为空");
		$('#code').focus();
		return false;
	}
	if(isMobile(mobile)) {
		$.ajax({
			url: 'url',
			type: "GET",
			dataType: "json",
			success: function(datas) {
				if(datas.status == 200) {
					layer.msg("提交成功 ^_^");
				} else if(datas.status == 407 || datas.status == 408) {
					layer.msg("验证码错误!");
				} else {
					layer.msg("网络错误 -_-");
				}
			},
			error: function(e) {
				layer.msg("网络错误 --");
			}
		});
	} else {
		layer.msg("手机号不正确");
		$('#mobile').focus();
	}
});

// -------  顶部高度适配
if(/(Android)/i.test(navigator.userAgent)) {
	document.getElementsByTagName('header')[0].style.height = '1rem'
}
if(/(iPhone|iPad|iPod|iOS)/i.test(navigator.userAgent)) {
	document.getElementsByTagName('header')[0].style.height = '1.7rem'
}

function bodyScroll(e) {
	e.preventDefault()
}

// ---------- 浏览器版本判断
var browser = {
	versions: function() {
		var u = navigator.userAgent,
			app = navigator.appVersion;
		return { //移动终端浏览器版本信息
			trident: u.indexOf('Trident') > -1, //IE内核
			presto: u.indexOf('Presto') > -1, //opera内核
			webKit: u.indexOf('AppleWebKit') > -1, //苹果、谷歌内核
			gecko: u.indexOf('Gecko') > -1 && u.indexOf('KHTML') == -1, //火狐内核
			mobile: !!u.match(/AppleWebKit.*Mobile.*/), //是否为移动终端
			ios: !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/), //ios终端
			android: u.indexOf('Android') > -1 || u.indexOf('Linux') > -1, //android终端或uc浏览器
			iPhone: u.indexOf('iPhone') > -1, //是否为iPhone或者QQHD浏览器
			iPad: u.indexOf('iPad') > -1, //是否iPad
			webApp: u.indexOf('Safari') == -1 //是否web应该程序，没有头部与底部
		};
	}(),
	language: (navigator.browserLanguage || navigator.language).toLowerCase()
}
if(browser.versions.mobile) {
	if(ua.match(/MicroMessenger/i) == "micromessenger") {
		console.log('微信');
		if(browser.versions.ios) {
			console.log('在IOS浏览器中打开');
		} else {
			console.log('在安卓浏览器中打开');
		}
	} else {
		console.log('浏览器');
		if(browser.versions.ios) {
			console.log('在IOS浏览器中打开');
		} else {
			console.log('在安卓浏览器中打开');
		}
	}

} else {
	console.log('请在移动端打开');
	alert('请在移动端打开');
}


/**
 *
 * 　　　┏┓　　　┏┓
 * 　　┏┛┻━━━┛┻┓
 * 　　┃　　　　　　　┃
 * 　　┃　　　━　　　┃
 * 　　┃　┳┛　┗┳　┃
 * 　　┃　　　　　　　┃
 * 　　┃　　　┻　　　┃
 * 　　┃　　　　　　　┃
 * 　　┗━┓　　　┏━┛Code is far away from bug with the animal protecting
 * 　　　　┃　　　┃    神兽保佑,代码无bug
 * 　　　　┃　　　┃
 * 　　　　┃　　　┗━━━┓
 * 　　　　┃　　　　　 ┣┓
 * 　　　　┃　　　　 ┏┛
 * 　　　　┗┓┓┏━┳┓┏┛
 * 　　　　　┃┫┫　┃┫┫
 * 　　　　　┗┻┛　┗┻┛
 *
 */
