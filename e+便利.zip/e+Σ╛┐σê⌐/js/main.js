var layerObj = function(){
	this.setLayerPos = function setLayerPos(){
		$('.layerBox').css({'margin-left': -$('.layerBox').innerWidth()/2}).addClass('layer-ani');
	},
	this.addEle = function addEle(){
		$('body').append(
			'<div class="layerBox">'+
				'<div class="layerContent"></div>'+
			'</div>'
		);
	},
	this.msg = function msg(text,time){
		if($('.layerBox').length > 0){
			$('.layerBox').remove();
			return;
		}else{
			this.addEle();
		}

		$('.layerContent').html(text).css({'opacity':1});
		this.setLayerPos();
		var timer = setTimeout(function(){
			$('.layerBox').remove();
			clearTimeout(timer);
		},time)	
	}
}
var layer = new layerObj();

layer.msg('hello');