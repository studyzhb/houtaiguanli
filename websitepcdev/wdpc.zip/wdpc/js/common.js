var shopRecomendName  = "热门店铺";
var goodsRecomendName = "热门商品";
var goToWhere='tour.html?cityid=1&navid=';
var shopDetailUrl='shopDetail.html?id=';
var goodsDetailUrl="delicacy.html?id=";
var discountInfo='discount.html?id=';
/**
 * 标签位置属性
 */
var LabelField={
    labelA:'shop',
    labelB:'server',
    labelC:'fieldC'
}